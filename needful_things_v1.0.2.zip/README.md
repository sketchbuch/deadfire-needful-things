# deadfire_needful_things
A Mod for Pillars of Eternity 2: Deadfire that adds an item vendor that sells all unique arms and armour.
