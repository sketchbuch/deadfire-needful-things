import * as path from 'path'
import { packageExtension } from './packageExtension'

describe('packageExtension()', () => {
  const OUTPUT_DIR = path.join()

  test('Calls writeFileSync correctly for test', () => {
    packageExtension(OUTPUT_DIR, '1.0.2')
  })
})
